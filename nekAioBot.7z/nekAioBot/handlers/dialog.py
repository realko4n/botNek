from aiogram import Router
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import StatesGroup, State
from aiogram.types import Message

router = Router()

class OrderFood(StatesGroup):
    choosing_food_name = State()
    choosing_food_size = State()
    NAME = State()
    YOURFRIEND = State()
    WASAP = State()
    PASSION = State()
    KNOWLEDGE = State()

class happyQuestion(StatesGroup):
    NAME = State()
    YOURFRIEND = State()
    WASAP = State()
    PASSION = State()
    KNOWLEDGE = State()


@router.message(Command("quest"))
async def cmd_quest(message: Message, state: FSMContext):
    await message.answer(
        text='Привет, как тебя зовут?'
    )
    # Устанавливаем пользователю состояние "выбирает название"
    await state.set_state(happyQuestion.NAME)


@router.message(happyQuestion.NAME)
async def getName(message: Message, state: FSMContext):
    await state.update_data(name=message.text.lower())
    print(state.key)
    await message.answer(
        text=f"Приятно познакомиться,{message.text.capitalize()}\n"
             "Теперь, пожалуйста, напиши пару добрых слов о друге, который тебя пригласил."
    )
    await state.set_state(happyQuestion.YOURFRIEND)

@router.message(happyQuestion.YOURFRIEND)
async def getYourFriend(message: Message, state: FSMContext):
    await state.update_data(friend=message.text.lower())
    print(state.key)
    await message.answer(
        text="Думаю ему будет приятно!\n"
             "Расскажи, чем ты занимаешься?"
    )
    await state.set_state(happyQuestion.WASAP)

@router.message(happyQuestion.WASAP)
async def getWasap(message: Message, state: FSMContext):
    await state.update_data(wasap=message.text.lower())
    print(state.key)
    await message.answer(
        text="Очень интересно!\n"
             "Что в жизни тебя радует и вдохновляет?"
    )
    await state.set_state(happyQuestion.PASSION)

@router.message(happyQuestion.PASSION)
async def getPassion(message: Message, state: FSMContext):
    await state.update_data(passion=message.text.lower())
    print(state.key)
    await message.answer(
        text="Интересно!\n"
             "Чем готов делиться с сообществом, в чем можешь быть ему полезен?"
    )
    await state.set_state(happyQuestion.KNOWLEDGE)

@router.message(happyQuestion.KNOWLEDGE)
async def getSkill(message: Message, state: FSMContext):
    await state.update_data(knowledge=message.text.lower())
    print(state.key)#айди юзера, чата, бота
    user_data = await state.get_data()
    print(user_data.items())# инфа переданная

    await message.answer(
        text=f"{user_data['name'].capitalize()}, спасибо за диалог.\n"
    )
    # Сброс состояния и сохранённых данных у пользователя
    await state.clear()







